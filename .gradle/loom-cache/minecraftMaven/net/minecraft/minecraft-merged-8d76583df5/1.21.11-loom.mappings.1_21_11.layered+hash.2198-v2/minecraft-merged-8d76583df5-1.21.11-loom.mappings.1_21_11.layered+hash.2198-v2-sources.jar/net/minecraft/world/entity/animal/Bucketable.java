package net.minecraft.world.entity.animal;

import java.util.Optional;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;

public interface Bucketable {
	boolean fromBucket();

	void setFromBucket(boolean bl);

	void saveToBucketTag(ItemStack itemStack);

	void loadFromBucketTag(CompoundTag compoundTag);

	ItemStack getBucketItemStack();

	SoundEvent getPickupSound();

	@Deprecated
	static void saveDefaultDataToBucketTag(Mob mob, ItemStack itemStack) {
		itemStack.copyFrom(DataComponents.CUSTOM_NAME, mob);
		CustomData.update(DataComponents.BUCKET_ENTITY_DATA, itemStack, compoundTag -> {
			if (mob.isNoAi()) {
				compoundTag.putBoolean("NoAI", mob.isNoAi());
			}

			if (mob.isSilent()) {
				compoundTag.putBoolean("Silent", mob.isSilent());
			}

			if (mob.isNoGravity()) {
				compoundTag.putBoolean("NoGravity", mob.isNoGravity());
			}

			if (mob.hasGlowingTag()) {
				compoundTag.putBoolean("Glowing", mob.hasGlowingTag());
			}

			if (mob.isInvulnerable()) {
				compoundTag.putBoolean("Invulnerable", mob.isInvulnerable());
			}

			compoundTag.putFloat("Health", mob.getHealth());
		});
	}

	@Deprecated
	static void loadDefaultDataFromBucketTag(Mob mob, CompoundTag compoundTag) {
		compoundTag.getBoolean("NoAI").ifPresent(mob::setNoAi);
		compoundTag.getBoolean("Silent").ifPresent(mob::setSilent);
		compoundTag.getBoolean("NoGravity").ifPresent(mob::setNoGravity);
		compoundTag.getBoolean("Glowing").ifPresent(mob::setGlowingTag);
		compoundTag.getBoolean("Invulnerable").ifPresent(mob::setInvulnerable);
		compoundTag.getFloat("Health").ifPresent(mob::setHealth);
	}

	static <T extends LivingEntity & Bucketable> Optional<InteractionResult> bucketMobPickup(Player player, InteractionHand interactionHand, T livingEntity) {
		ItemStack itemStack = player.getItemInHand(interactionHand);
		if (itemStack.getItem() == Items.WATER_BUCKET && livingEntity.isAlive()) {
			livingEntity.playSound(livingEntity.getPickupSound(), 1.0F, 1.0F);
			ItemStack itemStack2 = livingEntity.getBucketItemStack();
			livingEntity.saveToBucketTag(itemStack2);
			ItemStack itemStack3 = ItemUtils.createFilledResult(itemStack, player, itemStack2, false);
			player.setItemInHand(interactionHand, itemStack3);
			Level level = livingEntity.level();
			if (!level.isClientSide()) {
				CriteriaTriggers.FILLED_BUCKET.trigger((ServerPlayer)player, itemStack2);
			}

			livingEntity.discard();
			return Optional.of(InteractionResult.SUCCESS);
		} else {
			return Optional.empty();
		}
	}
}
