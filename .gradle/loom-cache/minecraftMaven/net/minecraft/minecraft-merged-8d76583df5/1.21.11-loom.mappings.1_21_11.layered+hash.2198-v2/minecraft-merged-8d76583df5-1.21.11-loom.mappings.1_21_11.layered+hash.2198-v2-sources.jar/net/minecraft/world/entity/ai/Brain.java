package net.minecraft.world.entity.ai;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.collect.ImmutableList.Builder;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.Dynamic;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.MapLike;
import com.mojang.serialization.RecordBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.VisibleForDebug;
import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.attribute.EnvironmentAttributeSystem;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.behavior.Behavior;
import net.minecraft.world.entity.ai.behavior.BehaviorControl;
import net.minecraft.world.entity.ai.memory.ExpirableValue;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.MemoryStatus;
import net.minecraft.world.entity.ai.sensing.Sensor;
import net.minecraft.world.entity.ai.sensing.SensorType;
import net.minecraft.world.entity.schedule.Activity;
import net.minecraft.world.phys.Vec3;
import org.apache.commons.lang3.mutable.MutableObject;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

public class Brain<E extends LivingEntity> {
	static final Logger LOGGER = LogUtils.getLogger();
	private final Supplier<Codec<Brain<E>>> codec;
	private static final int SCHEDULE_UPDATE_DELAY = 20;
	private final Map<MemoryModuleType<?>, Optional<? extends ExpirableValue<?>>> memories = Maps.newHashMap();
	private final Map<SensorType<? extends Sensor<? super E>>, Sensor<? super E>> sensors = Maps.newLinkedHashMap();
	private final Map<Integer, Map<Activity, Set<BehaviorControl<? super E>>>> availableBehaviorsByPriority = Maps.newTreeMap();
	private @Nullable EnvironmentAttribute<Activity> schedule;
	private final Map<Activity, Set<Pair<MemoryModuleType<?>, MemoryStatus>>> activityRequirements = Maps.newHashMap();
	private final Map<Activity, Set<MemoryModuleType<?>>> activityMemoriesToEraseWhenStopped = Maps.newHashMap();
	private Set<Activity> coreActivities = Sets.newHashSet();
	private final Set<Activity> activeActivities = Sets.newHashSet();
	private Activity defaultActivity = Activity.IDLE;
	private long lastScheduleUpdate = -9999L;

	public static <E extends LivingEntity> Brain.Provider<E> provider(
		Collection<? extends MemoryModuleType<?>> collection, Collection<? extends SensorType<? extends Sensor<? super E>>> collection2
	) {
		return new Brain.Provider<>(collection, collection2);
	}

	public static <E extends LivingEntity> Codec<Brain<E>> codec(
		Collection<? extends MemoryModuleType<?>> collection, Collection<? extends SensorType<? extends Sensor<? super E>>> collection2
	) {
		final MutableObject<Codec<Brain<E>>> mutableObject = new MutableObject<>();
		mutableObject.setValue(
			(new MapCodec<Brain<E>>() {
					@Override
					public <T> Stream<T> keys(DynamicOps<T> dynamicOps) {
						return collection.stream()
							.flatMap(
								memoryModuleType -> memoryModuleType.getCodec()
									.map(codec -> BuiltInRegistries.MEMORY_MODULE_TYPE.getKey((MemoryModuleType<?>)memoryModuleType))
									.stream()
							)
							.map(identifier -> dynamicOps.createString(identifier.toString()));
					}

					@Override
					public <T> DataResult<Brain<E>> decode(DynamicOps<T> dynamicOps, MapLike<T> mapLike) {
						MutableObject<DataResult<Builder<Brain.MemoryValue<?>>>> mutableObjectx = new MutableObject<>(DataResult.success(ImmutableList.builder()));
						mapLike.entries()
							.forEach(
								pair -> {
									DataResult<MemoryModuleType<?>> dataResult = BuiltInRegistries.MEMORY_MODULE_TYPE.byNameCodec().parse(dynamicOps, pair.getFirst());
									DataResult<? extends Brain.MemoryValue<?>> dataResult2 = dataResult.flatMap(
										memoryModuleType -> this.captureRead((MemoryModuleType<T>)memoryModuleType, dynamicOps, (T)pair.getSecond())
									);
									mutableObject.setValue(mutableObject.get().apply2(Builder::add, dataResult2));
								}
							);
						ImmutableList<Brain.MemoryValue<?>> immutableList = mutableObjectx.get()
							.resultOrPartial(Brain.LOGGER::error)
							.map(Builder::build)
							.orElseGet(ImmutableList::of);
						return DataResult.success(new Brain<>(collection, collection2, immutableList, mutableObject));
					}

					private <T, U> DataResult<Brain.MemoryValue<U>> captureRead(MemoryModuleType<U> memoryModuleType, DynamicOps<T> dynamicOps, T object) {
						return memoryModuleType.getCodec()
							.map(DataResult::success)
							.orElseGet(() -> DataResult.error(() -> "No codec for memory: " + memoryModuleType))
							.<ExpirableValue<U>>flatMap(codec -> codec.parse(dynamicOps, object))
							.map(expirableValue -> new Brain.MemoryValue<>(memoryModuleType, Optional.of(expirableValue)));
					}

					public <T> RecordBuilder<T> encode(Brain<E> brain, DynamicOps<T> dynamicOps, RecordBuilder<T> recordBuilder) {
						brain.memories().forEach(memoryValue -> memoryValue.serialize(dynamicOps, recordBuilder));
						return recordBuilder;
					}
				})
				.fieldOf("memories")
				.codec()
		);
		return mutableObject.get();
	}

	public Brain(
		Collection<? extends MemoryModuleType<?>> collection,
		Collection<? extends SensorType<? extends Sensor<? super E>>> collection2,
		ImmutableList<Brain.MemoryValue<?>> immutableList,
		Supplier<Codec<Brain<E>>> supplier
	) {
		this.codec = supplier;

		for (MemoryModuleType<?> memoryModuleType : collection) {
			this.memories.put(memoryModuleType, Optional.empty());
		}

		for (SensorType<? extends Sensor<? super E>> sensorType : collection2) {
			this.sensors.put(sensorType, (Sensor<? super E>)sensorType.create());
		}

		for (Sensor<? super E> sensor : this.sensors.values()) {
			for (MemoryModuleType<?> memoryModuleType2 : sensor.requires()) {
				this.memories.put(memoryModuleType2, Optional.empty());
			}
		}

		for (Brain.MemoryValue<?> memoryValue : immutableList) {
			memoryValue.setMemoryInternal(this);
		}
	}

	public <T> DataResult<T> serializeStart(DynamicOps<T> dynamicOps) {
		return this.codec.get().encodeStart(dynamicOps, this);
	}

	Stream<Brain.MemoryValue<?>> memories() {
		return this.memories.entrySet().stream().map(entry -> Brain.MemoryValue.createUnchecked(entry.getKey(), entry.getValue()));
	}

	public boolean hasMemoryValue(MemoryModuleType<?> memoryModuleType) {
		return this.checkMemory(memoryModuleType, MemoryStatus.VALUE_PRESENT);
	}

	public void clearMemories() {
		this.memories.keySet().forEach(memoryModuleType -> this.memories.put((MemoryModuleType<?>)memoryModuleType, Optional.empty()));
	}

	public <U> void eraseMemory(MemoryModuleType<U> memoryModuleType) {
		this.setMemory(memoryModuleType, Optional.empty());
	}

	public <U> void setMemory(MemoryModuleType<U> memoryModuleType, @Nullable U object) {
		this.setMemory(memoryModuleType, Optional.ofNullable(object));
	}

	public <U> void setMemoryWithExpiry(MemoryModuleType<U> memoryModuleType, U object, long l) {
		this.setMemoryInternal(memoryModuleType, Optional.of(ExpirableValue.of(object, l)));
	}

	public <U> void setMemory(MemoryModuleType<U> memoryModuleType, Optional<? extends U> optional) {
		this.setMemoryInternal(memoryModuleType, optional.map(ExpirableValue::of));
	}

	<U> void setMemoryInternal(MemoryModuleType<U> memoryModuleType, Optional<? extends ExpirableValue<?>> optional) {
		if (this.memories.containsKey(memoryModuleType)) {
			if (optional.isPresent() && this.isEmptyCollection(optional.get().getValue())) {
				this.eraseMemory(memoryModuleType);
			} else {
				this.memories.put(memoryModuleType, optional);
			}
		}
	}

	public <U> Optional<U> getMemory(MemoryModuleType<U> memoryModuleType) {
		Optional<? extends ExpirableValue<?>> optional = this.memories.get(memoryModuleType);
		if (optional == null) {
			throw new IllegalStateException("Unregistered memory fetched: " + memoryModuleType);
		} else {
			return optional.map(ExpirableValue::getValue);
		}
	}

	public <U> @Nullable Optional<U> getMemoryInternal(MemoryModuleType<U> memoryModuleType) {
		Optional<? extends ExpirableValue<?>> optional = this.memories.get(memoryModuleType);
		return optional == null ? null : optional.map(ExpirableValue::getValue);
	}

	public <U> long getTimeUntilExpiry(MemoryModuleType<U> memoryModuleType) {
		Optional<? extends ExpirableValue<?>> optional = this.memories.get(memoryModuleType);
		return optional.map(ExpirableValue::getTimeToLive).orElse(0L);
	}

	@Deprecated
	@VisibleForDebug
	public Map<MemoryModuleType<?>, Optional<? extends ExpirableValue<?>>> getMemories() {
		return this.memories;
	}

	public <U> boolean isMemoryValue(MemoryModuleType<U> memoryModuleType, U object) {
		return !this.hasMemoryValue(memoryModuleType) ? false : this.getMemory(memoryModuleType).filter(object2 -> object2.equals(object)).isPresent();
	}

	public boolean checkMemory(MemoryModuleType<?> memoryModuleType, MemoryStatus memoryStatus) {
		Optional<? extends ExpirableValue<?>> optional = this.memories.get(memoryModuleType);
		return optional == null
			? false
			: memoryStatus == MemoryStatus.REGISTERED
				|| memoryStatus == MemoryStatus.VALUE_PRESENT && optional.isPresent()
				|| memoryStatus == MemoryStatus.VALUE_ABSENT && optional.isEmpty();
	}

	public void setSchedule(EnvironmentAttribute<Activity> environmentAttribute) {
		this.schedule = environmentAttribute;
	}

	public void setCoreActivities(Set<Activity> set) {
		this.coreActivities = set;
	}

	@Deprecated
	@VisibleForDebug
	public Set<Activity> getActiveActivities() {
		return this.activeActivities;
	}

	@Deprecated
	@VisibleForDebug
	public List<BehaviorControl<? super E>> getRunningBehaviors() {
		List<BehaviorControl<? super E>> list = new ObjectArrayList<>();

		for (Map<Activity, Set<BehaviorControl<? super E>>> map : this.availableBehaviorsByPriority.values()) {
			for (Set<BehaviorControl<? super E>> set : map.values()) {
				for (BehaviorControl<? super E> behaviorControl : set) {
					if (behaviorControl.getStatus() == Behavior.Status.RUNNING) {
						list.add(behaviorControl);
					}
				}
			}
		}

		return list;
	}

	public void useDefaultActivity() {
		this.setActiveActivity(this.defaultActivity);
	}

	public Optional<Activity> getActiveNonCoreActivity() {
		for (Activity activity : this.activeActivities) {
			if (!this.coreActivities.contains(activity)) {
				return Optional.of(activity);
			}
		}

		return Optional.empty();
	}

	public void setActiveActivityIfPossible(Activity activity) {
		if (this.activityRequirementsAreMet(activity)) {
			this.setActiveActivity(activity);
		} else {
			this.useDefaultActivity();
		}
	}

	private void setActiveActivity(Activity activity) {
		if (!this.isActive(activity)) {
			this.eraseMemoriesForOtherActivitesThan(activity);
			this.activeActivities.clear();
			this.activeActivities.addAll(this.coreActivities);
			this.activeActivities.add(activity);
		}
	}

	private void eraseMemoriesForOtherActivitesThan(Activity activity) {
		for (Activity activity2 : this.activeActivities) {
			if (activity2 != activity) {
				Set<MemoryModuleType<?>> set = this.activityMemoriesToEraseWhenStopped.get(activity2);
				if (set != null) {
					for (MemoryModuleType<?> memoryModuleType : set) {
						this.eraseMemory(memoryModuleType);
					}
				}
			}
		}
	}

	public void updateActivityFromSchedule(EnvironmentAttributeSystem environmentAttributeSystem, long l, Vec3 vec3) {
		if (l - this.lastScheduleUpdate > 20L) {
			this.lastScheduleUpdate = l;
			Activity activity = this.schedule != null ? environmentAttributeSystem.getValue(this.schedule, vec3) : Activity.IDLE;
			if (!this.activeActivities.contains(activity)) {
				this.setActiveActivityIfPossible(activity);
			}
		}
	}

	public void setActiveActivityToFirstValid(List<Activity> list) {
		for (Activity activity : list) {
			if (this.activityRequirementsAreMet(activity)) {
				this.setActiveActivity(activity);
				break;
			}
		}
	}

	public void setDefaultActivity(Activity activity) {
		this.defaultActivity = activity;
	}

	public void addActivity(Activity activity, int i, ImmutableList<? extends BehaviorControl<? super E>> immutableList) {
		this.addActivity(activity, this.createPriorityPairs(i, immutableList));
	}

	public void addActivityAndRemoveMemoryWhenStopped(
		Activity activity, int i, ImmutableList<? extends BehaviorControl<? super E>> immutableList, MemoryModuleType<?> memoryModuleType
	) {
		Set<Pair<MemoryModuleType<?>, MemoryStatus>> set = ImmutableSet.of(Pair.of(memoryModuleType, MemoryStatus.VALUE_PRESENT));
		Set<MemoryModuleType<?>> set2 = ImmutableSet.of(memoryModuleType);
		this.addActivityAndRemoveMemoriesWhenStopped(activity, this.createPriorityPairs(i, immutableList), set, set2);
	}

	public void addActivity(Activity activity, ImmutableList<? extends Pair<Integer, ? extends BehaviorControl<? super E>>> immutableList) {
		this.addActivityAndRemoveMemoriesWhenStopped(activity, immutableList, ImmutableSet.of(), Sets.newHashSet());
	}

	public void addActivityWithConditions(
		Activity activity, int i, ImmutableList<? extends BehaviorControl<? super E>> immutableList, Set<Pair<MemoryModuleType<?>, MemoryStatus>> set
	) {
		this.addActivityWithConditions(activity, this.createPriorityPairs(i, immutableList), set);
	}

	public void addActivityWithConditions(
		Activity activity,
		ImmutableList<? extends Pair<Integer, ? extends BehaviorControl<? super E>>> immutableList,
		Set<Pair<MemoryModuleType<?>, MemoryStatus>> set
	) {
		this.addActivityAndRemoveMemoriesWhenStopped(activity, immutableList, set, Sets.newHashSet());
	}

	public void addActivityAndRemoveMemoriesWhenStopped(
		Activity activity,
		ImmutableList<? extends Pair<Integer, ? extends BehaviorControl<? super E>>> immutableList,
		Set<Pair<MemoryModuleType<?>, MemoryStatus>> set,
		Set<MemoryModuleType<?>> set2
	) {
		this.activityRequirements.put(activity, set);
		if (!set2.isEmpty()) {
			this.activityMemoriesToEraseWhenStopped.put(activity, set2);
		}

		for (Pair<Integer, ? extends BehaviorControl<? super E>> pair : immutableList) {
			this.availableBehaviorsByPriority
				.computeIfAbsent(pair.getFirst(), integer -> Maps.newHashMap())
				.computeIfAbsent(activity, activityx -> Sets.newLinkedHashSet())
				.add((BehaviorControl<? super E>)pair.getSecond());
		}
	}

	@VisibleForTesting
	public void removeAllBehaviors() {
		this.availableBehaviorsByPriority.clear();
	}

	public boolean isActive(Activity activity) {
		return this.activeActivities.contains(activity);
	}

	public Brain<E> copyWithoutBehaviors() {
		Brain<E> brain = new Brain<>(this.memories.keySet(), this.sensors.keySet(), ImmutableList.of(), this.codec);

		for (Entry<MemoryModuleType<?>, Optional<? extends ExpirableValue<?>>> entry : this.memories.entrySet()) {
			MemoryModuleType<?> memoryModuleType = entry.getKey();
			if (entry.getValue().isPresent()) {
				brain.memories.put(memoryModuleType, entry.getValue());
			}
		}

		return brain;
	}

	public void tick(ServerLevel serverLevel, E livingEntity) {
		this.forgetOutdatedMemories();
		this.tickSensors(serverLevel, livingEntity);
		this.startEachNonRunningBehavior(serverLevel, livingEntity);
		this.tickEachRunningBehavior(serverLevel, livingEntity);
	}

	private void tickSensors(ServerLevel serverLevel, E livingEntity) {
		for (Sensor<? super E> sensor : this.sensors.values()) {
			sensor.tick(serverLevel, livingEntity);
		}
	}

	private void forgetOutdatedMemories() {
		for (Entry<MemoryModuleType<?>, Optional<? extends ExpirableValue<?>>> entry : this.memories.entrySet()) {
			if (entry.getValue().isPresent()) {
				ExpirableValue<?> expirableValue = (ExpirableValue<?>)entry.getValue().get();
				if (expirableValue.hasExpired()) {
					this.eraseMemory(entry.getKey());
				}

				expirableValue.tick();
			}
		}
	}

	public void stopAll(ServerLevel serverLevel, E livingEntity) {
		long l = livingEntity.level().getGameTime();

		for (BehaviorControl<? super E> behaviorControl : this.getRunningBehaviors()) {
			behaviorControl.doStop(serverLevel, livingEntity, l);
		}
	}

	private void startEachNonRunningBehavior(ServerLevel serverLevel, E livingEntity) {
		long l = serverLevel.getGameTime();

		for (Map<Activity, Set<BehaviorControl<? super E>>> map : this.availableBehaviorsByPriority.values()) {
			for (Entry<Activity, Set<BehaviorControl<? super E>>> entry : map.entrySet()) {
				Activity activity = entry.getKey();
				if (this.activeActivities.contains(activity)) {
					for (BehaviorControl<? super E> behaviorControl : entry.getValue()) {
						if (behaviorControl.getStatus() == Behavior.Status.STOPPED) {
							behaviorControl.tryStart(serverLevel, livingEntity, l);
						}
					}
				}
			}
		}
	}

	private void tickEachRunningBehavior(ServerLevel serverLevel, E livingEntity) {
		long l = serverLevel.getGameTime();

		for (BehaviorControl<? super E> behaviorControl : this.getRunningBehaviors()) {
			behaviorControl.tickOrStop(serverLevel, livingEntity, l);
		}
	}

	private boolean activityRequirementsAreMet(Activity activity) {
		if (!this.activityRequirements.containsKey(activity)) {
			return false;
		}

		for (Pair<MemoryModuleType<?>, MemoryStatus> pair : this.activityRequirements.get(activity)) {
			MemoryModuleType<?> memoryModuleType = pair.getFirst();
			MemoryStatus memoryStatus = pair.getSecond();
			if (!this.checkMemory(memoryModuleType, memoryStatus)) {
				return false;
			}
		}

		return true;
	}

	private boolean isEmptyCollection(Object object) {
		return object instanceof Collection && ((Collection)object).isEmpty();
	}

	ImmutableList<? extends Pair<Integer, ? extends BehaviorControl<? super E>>> createPriorityPairs(
		int i, ImmutableList<? extends BehaviorControl<? super E>> immutableList
	) {
		int j = i;
		Builder<Pair<Integer, ? extends BehaviorControl<? super E>>> builder = ImmutableList.builder();

		for (BehaviorControl<? super E> behaviorControl : immutableList) {
			builder.add(Pair.of(j++, behaviorControl));
		}

		return builder.build();
	}

	public boolean isBrainDead() {
		return this.memories.isEmpty() && this.sensors.isEmpty() && this.availableBehaviorsByPriority.isEmpty();
	}

	static final class MemoryValue<U> {
		private final MemoryModuleType<U> type;
		private final Optional<? extends ExpirableValue<U>> value;

		static <U> Brain.MemoryValue<U> createUnchecked(MemoryModuleType<U> memoryModuleType, Optional<? extends ExpirableValue<?>> optional) {
			return new Brain.MemoryValue<>(memoryModuleType, (Optional<? extends ExpirableValue<U>>)optional);
		}

		MemoryValue(MemoryModuleType<U> memoryModuleType, Optional<? extends ExpirableValue<U>> optional) {
			this.type = memoryModuleType;
			this.value = optional;
		}

		void setMemoryInternal(Brain<?> brain) {
			brain.setMemoryInternal(this.type, this.value);
		}

		public <T> void serialize(DynamicOps<T> dynamicOps, RecordBuilder<T> recordBuilder) {
			this.type
				.getCodec()
				.ifPresent(
					codec -> this.value
						.ifPresent(
							expirableValue -> recordBuilder.add(
								BuiltInRegistries.MEMORY_MODULE_TYPE.byNameCodec().encodeStart(dynamicOps, this.type), codec.encodeStart(dynamicOps, (ExpirableValue<U>)expirableValue)
							)
						)
				);
		}
	}

	public static final class Provider<E extends LivingEntity> {
		private final Collection<? extends MemoryModuleType<?>> memoryTypes;
		private final Collection<? extends SensorType<? extends Sensor<? super E>>> sensorTypes;
		private final Codec<Brain<E>> codec;

		Provider(Collection<? extends MemoryModuleType<?>> collection, Collection<? extends SensorType<? extends Sensor<? super E>>> collection2) {
			this.memoryTypes = collection;
			this.sensorTypes = collection2;
			this.codec = Brain.codec(collection, collection2);
		}

		public Brain<E> makeBrain(Dynamic<?> dynamic) {
			return this.codec
				.parse(dynamic)
				.resultOrPartial(Brain.LOGGER::error)
				.orElseGet(() -> new Brain<>(this.memoryTypes, this.sensorTypes, ImmutableList.of(), () -> this.codec));
		}
	}
}
