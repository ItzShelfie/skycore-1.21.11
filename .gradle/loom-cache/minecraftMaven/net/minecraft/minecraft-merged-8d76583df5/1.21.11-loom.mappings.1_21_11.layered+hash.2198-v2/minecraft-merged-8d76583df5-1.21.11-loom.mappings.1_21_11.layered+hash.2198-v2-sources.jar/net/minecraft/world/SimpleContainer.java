package net.minecraft.world;

import com.google.common.collect.Lists;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.core.NonNullList;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.StackedItemContents;
import net.minecraft.world.inventory.StackedContentsCompatible;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jspecify.annotations.Nullable;

public class SimpleContainer implements Container, StackedContentsCompatible {
	private final int size;
	public final NonNullList<ItemStack> items;
	private @Nullable List<ContainerListener> listeners;

	public SimpleContainer(int i) {
		this.size = i;
		this.items = NonNullList.withSize(i, ItemStack.EMPTY);
	}

	public SimpleContainer(ItemStack... itemStacks) {
		this.size = itemStacks.length;
		this.items = NonNullList.of(ItemStack.EMPTY, itemStacks);
	}

	public void addListener(ContainerListener containerListener) {
		if (this.listeners == null) {
			this.listeners = Lists.newArrayList();
		}

		this.listeners.add(containerListener);
	}

	public void removeListener(ContainerListener containerListener) {
		if (this.listeners != null) {
			this.listeners.remove(containerListener);
		}
	}

	@Override
	public ItemStack getItem(int i) {
		return i >= 0 && i < this.items.size() ? this.items.get(i) : ItemStack.EMPTY;
	}

	public List<ItemStack> removeAllItems() {
		List<ItemStack> list = this.items.stream().filter(itemStack -> !itemStack.isEmpty()).collect(Collectors.toList());
		this.clearContent();
		return list;
	}

	@Override
	public ItemStack removeItem(int i, int j) {
		ItemStack itemStack = ContainerHelper.removeItem(this.items, i, j);
		if (!itemStack.isEmpty()) {
			this.setChanged();
		}

		return itemStack;
	}

	public ItemStack removeItemType(Item item, int i) {
		ItemStack itemStack = new ItemStack(item, 0);

		for (int j = this.size - 1; j >= 0; j--) {
			ItemStack itemStack2 = this.getItem(j);
			if (itemStack2.getItem().equals(item)) {
				int k = i - itemStack.getCount();
				ItemStack itemStack3 = itemStack2.split(k);
				itemStack.grow(itemStack3.getCount());
				if (itemStack.getCount() == i) {
					break;
				}
			}
		}

		if (!itemStack.isEmpty()) {
			this.setChanged();
		}

		return itemStack;
	}

	public ItemStack addItem(ItemStack itemStack) {
		if (itemStack.isEmpty()) {
			return ItemStack.EMPTY;
		}

		ItemStack itemStack2 = itemStack.copy();
		this.moveItemToOccupiedSlotsWithSameType(itemStack2);
		if (itemStack2.isEmpty()) {
			return ItemStack.EMPTY;
		}

		this.moveItemToEmptySlots(itemStack2);
		return itemStack2.isEmpty() ? ItemStack.EMPTY : itemStack2;
	}

	public boolean canAddItem(ItemStack itemStack) {
		boolean bl = false;

		for (ItemStack itemStack2 : this.items) {
			if (itemStack2.isEmpty() || ItemStack.isSameItemSameComponents(itemStack2, itemStack) && itemStack2.getCount() < itemStack2.getMaxStackSize()) {
				bl = true;
				break;
			}
		}

		return bl;
	}

	@Override
	public ItemStack removeItemNoUpdate(int i) {
		ItemStack itemStack = this.items.get(i);
		if (itemStack.isEmpty()) {
			return ItemStack.EMPTY;
		}

		this.items.set(i, ItemStack.EMPTY);
		return itemStack;
	}

	@Override
	public void setItem(int i, ItemStack itemStack) {
		this.items.set(i, itemStack);
		itemStack.limitSize(this.getMaxStackSize(itemStack));
		this.setChanged();
	}

	@Override
	public int getContainerSize() {
		return this.size;
	}

	@Override
	public boolean isEmpty() {
		for (ItemStack itemStack : this.items) {
			if (!itemStack.isEmpty()) {
				return false;
			}
		}

		return true;
	}

	@Override
	public void setChanged() {
		if (this.listeners != null) {
			for (ContainerListener containerListener : this.listeners) {
				containerListener.containerChanged(this);
			}
		}
	}

	@Override
	public boolean stillValid(Player player) {
		return true;
	}

	@Override
	public void clearContent() {
		this.items.clear();
		this.setChanged();
	}

	@Override
	public void fillStackedContents(StackedItemContents stackedItemContents) {
		for (ItemStack itemStack : this.items) {
			stackedItemContents.accountStack(itemStack);
		}
	}

	@Override
	public String toString() {
		return this.items.stream().filter(itemStack -> !itemStack.isEmpty()).collect(Collectors.toList()).toString();
	}

	private void moveItemToEmptySlots(ItemStack itemStack) {
		for (int i = 0; i < this.size; i++) {
			ItemStack itemStack2 = this.getItem(i);
			if (itemStack2.isEmpty()) {
				this.setItem(i, itemStack.copyAndClear());
				return;
			}
		}
	}

	private void moveItemToOccupiedSlotsWithSameType(ItemStack itemStack) {
		for (int i = 0; i < this.size; i++) {
			ItemStack itemStack2 = this.getItem(i);
			if (ItemStack.isSameItemSameComponents(itemStack2, itemStack)) {
				this.moveItemsBetweenStacks(itemStack, itemStack2);
				if (itemStack.isEmpty()) {
					return;
				}
			}
		}
	}

	private void moveItemsBetweenStacks(ItemStack itemStack, ItemStack itemStack2) {
		int i = this.getMaxStackSize(itemStack2);
		int j = Math.min(itemStack.getCount(), i - itemStack2.getCount());
		if (j > 0) {
			itemStack2.grow(j);
			itemStack.shrink(j);
			this.setChanged();
		}
	}

	public void fromItemList(ValueInput.TypedInputList<ItemStack> typedInputList) {
		this.clearContent();

		for (ItemStack itemStack : typedInputList) {
			this.addItem(itemStack);
		}
	}

	public void storeAsItemList(ValueOutput.TypedOutputList<ItemStack> typedOutputList) {
		for (int i = 0; i < this.getContainerSize(); i++) {
			ItemStack itemStack = this.getItem(i);
			if (!itemStack.isEmpty()) {
				typedOutputList.add(itemStack);
			}
		}
	}

	public NonNullList<ItemStack> getItems() {
		return this.items;
	}
}
